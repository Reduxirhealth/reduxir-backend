# Reduxir CoachBot Backend

This is the Node.js backend for Reduxir CoachBot using OpenAI's GPT API.

## Deployment

1. Upload to GitHub
2. Connect to [Render](https://render.com)
3. Set Root Directory to `/` (or leave blank)
4. Add environment variable `OPENAI_API_KEY` (already included in `.env`)
5. Use Build Command: `npm install`
6. Start Command: `npm start`